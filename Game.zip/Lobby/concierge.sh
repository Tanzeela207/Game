#!/bin/bash
echo "Welcome, were so glad to have you! To stay busy until check-in time, we offer tons of activities such as 1)Offices 2)Soccer Fields 3)Lounges with Bars 4)Gaming Stations 5)Tennis Courts 6)Basketball Courts 7)Spas 8)Cinema 9)Restaurants and 10)Swimming Pools and 11)Rooftop Pools 12)Valet 13)cafeteria 14)CabanaClub 15)investigation"

echo "Input your favorite Activity's Number"
read variableA

Variable100="Aidana"
Variable101="Claudius"
Variable102="Corinne"
Variable103="Dana"
Variable104="Diyan"
Variable105="Highl"
Variable107="Nataliia"
Variable108="Floor_Winnie"
Variable109="Sarah"
Variable110="Sajini"
Variable111="Riad"
Variable112="Tanzeela"
Variable113="Mary Beth"




if [ $variableA = 1 ]; then
echo "Activity $variableA is located on floor $Variable100"

fi

if [ $variableA = 2 ]; then
echo "Activity $variableA is located on floor $Variable101"

fi

if [ $variableA = 3 ]; then
echo "Activity $variableA is located on floor $Variable102 take the elevator on up"

fi

if [ $variableA = 4 ]; then
echo "Activity $variableA is located on floor $Variable103"

fi

if [ $variableA = 5 ]; then
echo "Activity $variableA is located on floor $Variable104"

fi

if [ $variableA = 6 ]; then
echo "Activity $variableA is located on floor $Variable105"

fi

if [ $variableA = 7 ]; then
echo "Activity $variableA is located on floor $Variable106"

fi

if [ $variableA = 8 ]; then
echo "Activity $variableA is located on floor $Variable107"

fi

if [ $variableA = 9 ]; then
echo "Activity $variableA is located on $Variable108"

fi

if [ $variableA = 10 ]; then
echo "Activity $variableA is located on floor $Variable109"

fi

if [ $variableA = 11 ]; then
echo "Activity $variableA is located on floor $Variable110"

fi

if [ $variableA = 12 ]; then
echo "Activity $variableA is located on floor $Variable111"

fi

if [ $variableA = 13 ]; then
echo "Activity $variableA is located on floor $Variable112"

fi

if [ $variableA = 14 ]; then
echo "Activity $variableA is located on floor $Variable113"

fi

if [ $variableA = 15 ]; then
echo "Activity $variableA is located on floor Michael"

fi