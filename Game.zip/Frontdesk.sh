#!/bin/bash
echo "How many days will you be staying?"
read number
echo "$number days! thats great!"
echo "Check-in is at 3pm, leave your bags here and run over to our lobby they can tell you where to find our best amenities! the bellman will be sure to move your  bags up to your room"


