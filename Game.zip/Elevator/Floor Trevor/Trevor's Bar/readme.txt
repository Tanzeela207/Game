#!/bin/bash

Welcome to Trevor's Bar! 

The objective for this level is to get you drink on responsibly of course and help the bartender to gather ingredents for the mixed drinks.

It seems as if the bartender is new to bartending and needs a little help with the ingredients of a few of the most popular mixed drinks.

Select 6 ingredients that are commonly used in mixing some of your favorite drinks.
