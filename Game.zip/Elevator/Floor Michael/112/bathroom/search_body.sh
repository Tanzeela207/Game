#:!/bin/bash
cat body
cat ../blankpaper
echo The body is bloody and filled with bullets. You find a piece of paper on the body!
read -n 1 -s -r -p "Press any key to continue"          
clear
cd ~
cat Game/.e/resources/hidden/paper2
read -n 1 -s -r -p "Press any key to continue"          
clear





































































































#This is script!!!